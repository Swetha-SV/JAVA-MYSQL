import java.sql.*;
import java.util.Scanner;

public class Homepage {
    static final String DB_URL = "jdbc:mysql://localhost:3306/onlineworkshopsystem";
    static final String USER = "root";
    static final String PASS = "";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Connection conn = null;
        while (true) {
            int option = 0;
            try {
                conn = DriverManager.getConnection(DB_URL, USER, PASS);
                System.out.println("\t\t---------------------------------------------------------");
                System.out.println("\t\t|\tWelcome to Online Workshop Registration System\t| ");
                System.out.println("\t\t---------------------------------------------------------");
                System.out.println("\t\t\t1. Register");
                System.out.println("\t\t\t2. Login");
                System.out.println("\t\t\t3. Exit");
                System.out.println("\t\t-----------------------------------------------------------");
                System.out.print("\nPlease select an option: ");
                option = scanner.nextInt();
                scanner.nextLine();
                switch (option) {
                    case 1:
                        System.out.println("\n\t\t\t---------------------------------");
                        System.out.println("\t\t\t|\tUser Registeration\t| ");
                        System.out.println("\t\t\t---------------------------------\n");
                        registerUser(scanner, conn);
                        break;
                    case 2:
                        System.out.println("\n\t\t\t-------------------------");
                        System.out.println("\t\t\t|\tUser Login\t| ");
                        System.out.println("\t\t\t-------------------------\n");
                        login(scanner, conn);
                        break;
                    case 3:
                        System.out.println("Exiting the system. Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid option. Please try again.");
                        break;
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (conn != null) conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (option == 3) {
                break;
            }
        }
    }

    private static void registerUser(Scanner scanner, Connection conn) throws SQLException {
        System.out.println("\tPlease enter your details for registration\n");
        String name;
        System.out.print("Name: ");
        name = scanner.nextLine();
        String email;
        System.out.print("Email: ");
        email = scanner.nextLine();
        String password;
        System.out.print("Password: ");
        password = scanner.nextLine();
        String phoneNumber;
        System.out.print("Contact Number: ");
        phoneNumber = scanner.nextLine();
        String address;
        System.out.print("Address: ");
        address = scanner.nextLine();
        PreparedStatement stmt = conn.prepareStatement("INSERT INTO users (name, email, password, phone_number, address) VALUES (?, ?, ?, ?, ?)");
        stmt.setString(1, name);
        stmt.setString(2, email);
        stmt.setString(3, password);
        stmt.setString(4, phoneNumber);
        stmt.setString(5, address);

        int rowsAffected = stmt.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("Registered successfully. Welcome, " + name + "!");
        }
    }

    private static void login(Scanner scanner, Connection conn) throws SQLException {
        System.out.println("Please enter your email and password to login:");
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();

        if (email.equals("admin@gmail.com") && password.equals("admin")) {
            System.out.println("Admin Login Success!! ");
            adminOptions(scanner, conn);
        } else {
            userLogin(email, password, scanner, conn);
        }
    }

    private static void userLogin(String email, String password, Scanner scanner, Connection conn) throws SQLException {
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM users WHERE email = ? AND password = ?");
        stmt.setString(1, email);
        stmt.setString(2, password);
        ResultSet rs = stmt.executeQuery();
        int option ;

        if (rs.next()) {
            System.out.println("User Login Success!! ");
            int userId = rs.getInt("id");
            User user = new User();
            user.setId(userId);
            user.setName(rs.getString("name"));
            user.setEmail(email);
            user.setPhoneNumber(rs.getString("phone_number"));
            user.setAddress(rs.getString("address"));

            // Display user details
            System.out.println("User ID: " + user.getId());
            System.out.println("Name: " + user.getName());
            System.out.println("Email: " + user.getEmail());
            System.out.println("Phone Number: " + user.getPhoneNumber());
            System.out.println("Address: " + user.getAddress());
            do{
            // Provide options after successful login
            System.out.println("Select an option:");
            System.out.println("1. View the list of available workshops");
            System.out.println("2. View already enrolled workshops");
            System.out.println("3. View full details of a workshop");
            System.out.println("4. Enroll for a workshop");
            System.out.println("5.logout");
            System.out.print("Please select an option: ");
            option = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            // Implement logic based on the selected option
            switch (option) {
                case 1:
                    viewAvailableWorkshops(conn);
                    break;
                case 2:
                    viewEnrolledWorkshops(conn, userId);
                    break;
                case 3:
                    viewWorkshopDetails(scanner, conn);
                    break;
                case 4:
                    enrollWorkshop(scanner, conn, userId);
                    break;
                case 5:
                    System.out.println("logging out...");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
                    break;
            }
            }while(option!=5);
        } else {
            System.out.println("Invalid email or password. Please try again.");
        }
    }

    private static void viewAvailableWorkshops(Connection conn) throws SQLException {
        System.out.println("List of Available Workshops:");
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM workshops");

        while (rs.next()) {
            Workshop workshop = new Workshop();
            workshop.setId(rs.getInt("id"));
            workshop.setTitle(rs.getString("title"));
            workshop.setDescription(rs.getString("description"));
            // Populate other attributes as needed

            // Display workshop details
            System.out.println("Workshop ID: " + workshop.getId());
            System.out.println("Title: " + workshop.getTitle());
            System.out.println("Description: " + workshop.getDescription());
            // Display other attributes as needed
            System.out.println("---------------------------------");
        }
    }

    private static void viewEnrolledWorkshops(Connection conn, int userId) throws SQLException {
        System.out.println("List of Enrolled Workshops:");
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM enrollments WHERE user_id = ?");
        stmt.setInt(1, userId);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            int workshopId = rs.getInt("workshop_id");
            // Retrieve workshop details from workshops table based on workshopId
            PreparedStatement workshopStmt = conn.prepareStatement("SELECT * FROM workshops WHERE id = ?");
            workshopStmt.setInt(1, workshopId);
            ResultSet workshopRs = workshopStmt.executeQuery();

            if (workshopRs.next()) {
                Workshop workshop = new Workshop();
                workshop.setId(workshopRs.getInt("id"));
                workshop.setTitle(workshopRs.getString("title"));
                workshop.setDescription(workshopRs.getString("description"));
                // Populate other attributes as needed

                // Display workshop details
                System.out.println("Workshop ID: " + workshop.getId());
                System.out.println("Title: " + workshop.getTitle());
                System.out.println("Description: " + workshop.getDescription());
                // Display other attributes as needed
                System.out.println("---------------------------------");
            }
        }
    }

    private static void viewWorkshopDetails(Scanner scanner, Connection conn) throws SQLException {
        System.out.print("Enter the ID of the workshop to view details: ");
        int workshopId = scanner.nextInt();
        scanner.nextLine();
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM workshops WHERE id = ?");
        stmt.setInt(1, workshopId);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            Workshop workshop = new Workshop();
            workshop.setId(rs.getInt("id"));
            workshop.setTitle(rs.getString("title"));
            workshop.setDescription(rs.getString("description"));
            // Populate other attributes as needed

            // Display workshop details
            System.out.println("Workshop ID: " + workshop.getId());
            System.out.println("Title: " + workshop.getTitle());
            System.out.println("Description: " + workshop.getDescription());
            // Display other attributes as needed
        } else {
            System.out.println("Workshop with ID " + workshopId + " not found.");
        }
    }

    private static void enrollWorkshop(Scanner scanner, Connection conn, int userId) throws SQLException {
        System.out.print("Enter the ID of the workshop to enroll: ");
        int workshopId = scanner.nextInt();
        scanner.nextLine(); 
        PreparedStatement checkEnrollmentStmt = conn.prepareStatement("SELECT * FROM enrollments WHERE user_id = ? AND workshop_id = ?");
        checkEnrollmentStmt.setInt(1, userId);
        checkEnrollmentStmt.setInt(2, workshopId);
        ResultSet enrollmentRs = checkEnrollmentStmt.executeQuery();
        if (enrollmentRs.next()) {
            System.out.println("You are already enrolled in this workshop.");
            return;
        }

        PreparedStatement enrollStmt = conn.prepareStatement("INSERT INTO enrollments (user_id, workshop_id) VALUES (?, ?)");
        enrollStmt.setInt(1, userId);
        enrollStmt.setInt(2, workshopId);

        int rowsAffected = enrollStmt.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("Enrolled successfully in the workshop.");
        } else {
            System.out.println("Failed to enroll in the workshop.");
        }
    }

    private static void adminOptions(Scanner scanner, Connection conn) throws SQLException {
        while (true) {
            System.out.println("Admin Options:");
            System.out.println("1. Add workshop details");
            System.out.println("2. Remove workshop details");
            System.out.println("3. Update workshop details");
            System.out.println("4. Logout");

            System.out.print("Please select an option: ");
            int option = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (option) {
                case 1:
                    addWorkshop(scanner, conn);
                    break;
                case 2:
                    removeWorkshop(scanner, conn);
                    break;
                case 3:
                    updateWorkshop(scanner, conn);
                    break;
                case 4:
                    System.out.println("Logging out admin...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
                    break;
            }
        }
    }

    private static void addWorkshop(Scanner scanner, Connection conn) throws SQLException {
        System.out.println("Adding Workshop Details:");
        System.out.print("Title: ");
        String title = scanner.nextLine();
        System.out.print("Description: ");
        String description = scanner.nextLine();

        PreparedStatement stmt = conn.prepareStatement("INSERT INTO workshops (title, description) VALUES (?, ?)");
        stmt.setString(1, title);
        stmt.setString(2, description);

        int rowsAffected = stmt.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("Workshop details added successfully.");
        } else {
            System.out.println("Failed to add workshop details.");
        }
    }

    private static void removeWorkshop(Scanner scanner, Connection conn) throws SQLException {
        System.out.print("Enter the ID of the workshop to remove: ");
        int workshopId = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        PreparedStatement stmt = conn.prepareStatement("DELETE FROM workshops WHERE id = ?");
        stmt.setInt(1, workshopId);

        int rowsAffected = stmt.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("Workshop removed successfully.");
        } else {
            System.out.println("Failed to remove workshop.");
        }
    }

    private static void updateWorkshop(Scanner scanner, Connection conn) throws SQLException {
        System.out.print("Enter the ID of the workshop to update: ");
        int workshopId = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        System.out.print("Enter new title: ");
        String newTitle = scanner.nextLine();
        System.out.print("Enter new description: ");
        String newDescription = scanner.nextLine();

        PreparedStatement stmt = conn.prepareStatement("UPDATE workshops SET title = ?, description = ? WHERE id = ?");
        stmt.setString(1, newTitle);
        stmt.setString(2, newDescription);
        stmt.setInt(3, workshopId);

        int rowsAffected = stmt.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("Workshop details updated successfully.");
        } else {
            System.out.println("Failed to update workshop details.");
        }
    }
}
